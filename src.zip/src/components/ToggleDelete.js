import React from "react";

const ToggleDelete = () => {
  return (
    <>
      <div className="toggle-delete">
        <ul>
          <li>Delete</li>
        </ul>
      </div>
    </>
  );
};

export default ToggleDelete;
